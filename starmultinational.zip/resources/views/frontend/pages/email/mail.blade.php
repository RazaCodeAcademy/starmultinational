<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email Contact</title>
</head>
<body>
    <table>
        <tr>
            <td>
                {{$name}}
            </td>
        </tr>
        <tr>
            <td>
               Hello Admin
            </td>
        </tr>
        <tr>
            <td>
                &nbsp;
            </td>
        </tr>
        <tr>
            <td>
                {{$name}}
            </td>
        </tr>
        <tr>
            <td>
                &nbsp;
            </td>
        </tr>
        <tr>
            <td>
                {{$email}}
            </td>
        </tr>
        <tr>
            <td>
                &nbsp;
            </td>
        </tr>
        <tr>
            <td>
                {{$subject}}
            </td>
        </tr>
        <tr>
            <td>
                {{$msg}}
            </td>
        </tr>
        <tr>
            <td>
                &nbsp;
            </td>
        </tr>
        <tr>
            <td>
              Thanks and Regards
            </td>
        </tr>
    </table>
</body>
</html>